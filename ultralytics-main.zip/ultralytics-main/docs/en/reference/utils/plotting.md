---
title: utils.plotting API Reference
description: Explore detailed functionalities of Ultralytics plotting utilities for data visualizations and custom annotations in ML projects.
keywords: ultralytics, plotting, utilities, documentation, data visualization, annotations, python, ML tools
---

# Reference for `ultralytics/utils/plotting.py`

!!! success "Improvements"

    This page is sourced from [https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/plotting.py](https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/plotting.py). Have an improvement or example to add? Open a [Pull Request](https://docs.ultralytics.com/help/contributing) — thank you! 🙏

<br>

## ::: ultralytics.utils.plotting.Colors

<br><br><hr><br>

## ::: ultralytics.utils.plotting.Annotator

<br><br><hr><br>

## ::: ultralytics.utils.plotting._gaussian_filter1d

<br><br><hr><br>

## ::: ultralytics.utils.plotting._spectral_lut

<br><br><hr><br>

## ::: ultralytics.utils.plotting.colorize_depth

<br><br><hr><br>

## ::: ultralytics.utils.plotting.plot_labels

<br><br><hr><br>

## ::: ultralytics.utils.plotting.save_one_box

<br><br><hr><br>

## ::: ultralytics.utils.plotting.plot_images

<br><br><hr><br>

## ::: ultralytics.utils.plotting.plot_results

<br><br><hr><br>

## ::: ultralytics.utils.plotting.plot_multitrain_results

<br><br><hr><br>

## ::: ultralytics.utils.plotting.plt_color_scatter

<br><br><hr><br>

## ::: ultralytics.utils.plotting.plot_depth_panels

<br><br><hr><br>

## ::: ultralytics.utils.plotting.plot_tune_results

<br><br><hr><br>

## ::: ultralytics.utils.plotting.class_activation_map

<br><br>
