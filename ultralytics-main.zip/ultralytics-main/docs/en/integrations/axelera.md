---
comments: true
description: Deploy Ultralytics YOLO models on Axelera AI's Metis hardware. Learn how to export, compile, and run high-performance edge inference with up to 856 TOPS.
keywords: Axelera AI, Metis AIPU, Voyager SDK, Edge AI, YOLOv8, YOLO11, YOLO26, Model Export, Computer Vision, PCIe, M.2, Object Detection, quantization
---

# Axelera AI Export and Deployment

Ultralytics partners with [Axelera AI](https://axelera.ai/) to enable high-performance, energy-efficient inference on [Edge AI](https://www.ultralytics.com/glossary/edge-ai) devices. Export and deploy **Ultralytics YOLO models** directly to the **Metis® AIPU** using the **Voyager SDK**.

![Axelera AI edge deployment ecosystem for YOLO](https://github.com/user-attachments/assets/c97a0297-390d-47df-bb13-ff1aa499f34a)

Axelera AI provides dedicated hardware acceleration for [computer vision](https://www.ultralytics.com/glossary/computer-vision-cv) at the edge, using a proprietary dataflow architecture and [in-memory computing](https://www.ultralytics.com/glossary/edge-computing) to deliver up to **856 TOPS** with low power consumption.

## Selecting the Right Hardware

Axelera AI offers various form factors to suit different deployment constraints. The chart below helps identify the optimal hardware for your Ultralytics YOLO deployment.

```mermaid
graph TD
    A[Start: Select Deployment Target]:::start --> B{Device Type?}:::decide
    B -->|Edge Server / Workstation| C{Throughput Needs?}:::decide
    B -->|Embedded / Robotics| D{Space Constraints?}:::decide
    B -->|Standalone / R&D| E[Dev Kits & Systems]:::proc

    C -->|Max Density <br> 30+ Streams| F[**Metis PCIe x4**<br>856 TOPS]:::out
    C -->|Standard PC <br> Low Profile| G[**Metis PCIe x1**<br>214 TOPS]:::out

    D -->|Drones & Handhelds| H[**Metis M.2**<br>2280 M-Key]:::out
    D -->|High Performance Embedded| I[**Metis M.2 MAX**<br>Extended Thermal]:::out

    E -->|ARM-based All-in-One| J[**Metis Compute Board**<br>RK3588 + AIPU]:::out
    E -->|Prototyping| K[**Arduino Portenta x8**<br>Integration Kit]:::out

    click F "https://store.axelera.ai/"
    click G "https://store.axelera.ai/"
    click H "https://store.axelera.ai/"
    click J "https://store.axelera.ai/"

    classDef start fill:#4CAF50,color:#fff
    classDef proc fill:#2196F3,color:#fff
    classDef decide fill:#FF9800,color:#fff
    classDef out fill:#9C27B0,color:#fff
```

## Hardware Portfolio

The Axelera hardware lineup is optimized to run [Ultralytics YOLO26](../models/yolo26.md) and legacy versions with high FPS-per-watt efficiency.

### Accelerator Cards

These cards enable AI acceleration in existing host devices, facilitating [brownfield deployments](https://www.ultralytics.com/glossary/edge-computing).

| Product           | Form Factor    | Compute            | Performance (INT8) | Target Application                                                                                                                         |
| :---------------- | :------------- | :----------------- | :----------------- | :----------------------------------------------------------------------------------------------------------------------------------------- |
| **Metis PCIe x4** | PCIe Gen3 x16  | **4x** Metis AIPUs | **856 TOPS**       | High-density [video analytics](../guides/analytics.md), smart cities                                                                       |
| **Metis PCIe x1** | PCIe Gen3 x1   | **1x** Metis AIPU  | **214 TOPS**       | Industrial PCs, retail [queue management](../guides/queue-management.md)                                                                   |
| **Metis M.2**     | M.2 2280 M-Key | **1x** Metis AIPU  | **214 TOPS**       | [Drones](https://www.ultralytics.com/blog/build-ai-powered-drone-applications-with-ultralytics-yolo11), robotics, portable medical devices |
| **Metis M.2 MAX** | M.2 2280       | **1x** Metis AIPU  | **214 TOPS**       | Environments requiring advanced thermal management                                                                                         |

### Integrated Systems

For turnkey solutions, Axelera partners with manufacturers to provide systems pre-validated for the Metis AIPU.

- **Metis Compute Board**: A standalone edge device pairing the Metis AIPU with a Rockchip RK3588 ARM CPU.
- **Workstations**: Enterprise towers from **Dell** (Precision 3460XE) and **Lenovo** (ThinkStation P360 Ultra).
- **Industrial PCs**: Ruggedized systems from **Advantech** and **Aetina** designed for [manufacturing automation](https://www.ultralytics.com/solutions/computer-vision-in-manufacturing).

## Supported Tasks

Depth estimation is not supported: the depth head emits operators the Metis AIPU compiler cannot lower. YOLO26 instance segmentation is not supported by Ultralytics `export` either, but can still be deployed through the Voyager SDK as described below. YOLO26 semantic segmentation is supported.

{% set unsupported = ["depth", "yolo26-segment"] %}
{% include "macros/supported-tasks.md" %}

!!! note

    YOLO26 instance segmentation is not yet supported through the Ultralytics `export` command. Users who need `yolo26-seg` can deploy via the [Voyager SDK](https://github.com/axelera-ai-hub/voyager-sdk) using `deploy.py`, which provides a user-space workaround. Native compiler support will be added in a future release.

## Installation

!!! warning "Platform Requirements"

    Exporting to Axelera format requires:

    - **Operating System**: Linux only (Ubuntu 22.04/24.04 recommended)
    - **Hardware**: Axelera AI accelerator ([Metis devices](https://store.axelera.ai/))
    - **Python**: Versions 3.10, 3.11, 3.12, and 3.13
    - **PyTorch**: `torch>=2.8,<2.13`
    - **Voyager SDK**: 1.8.0; export installs this devkit version and inference installs this runtime version
    - **Metis kernel driver**: `metis-dkms` 1.6.2 or newer, installed separately from `pip`
    - **System dependency**: `sudo apt install libgl1` (required by OpenCV, not included via `pip`)

### Ultralytics Installation

```bash
pip install ultralytics
```

For detailed instructions, see our [Ultralytics Installation guide](../quickstart.md). If you encounter difficulties, consult our [Common Issues guide](../guides/yolo-common-issues.md).

### Axelera Driver Installation

1. Add the Axelera repository key:

    ```bash
    sudo sh -c "curl -fsSL https://software.axelera.ai/artifactory/api/security/keypair/axelera/public | gpg --dearmor -o /etc/apt/keyrings/axelera.gpg"
    ```

2. Add the repository to apt:

    Choose the appropriate snippet from below to match the OS being used.

    ```bash
    # Ubuntu 22.04
    sudo sh -c "echo 'deb [signed-by=/etc/apt/keyrings/axelera.gpg] https://software.axelera.ai/artifactory/axelera-apt-source ubuntu22 main' > /etc/apt/sources.list.d/axelera.list"
    ```

    ```bash
    # Ubuntu 24.04
    sudo sh -c "echo 'deb [signed-by=/etc/apt/keyrings/axelera.gpg] https://software.axelera.ai/artifactory/axelera-apt-source ubuntu24 main' > /etc/apt/sources.list.d/axelera.list"
    ```

3. Install the driver and load it. SDK 1.8 needs `metis-dkms` 1.6.2 or newer, so the newest is installed here:

    ```bash
    sudo apt update
    sudo apt install -y metis-dkms
    sudo modprobe metis
    ```

!!! note "Keep the kernel driver in sync with the SDK"

    The kernel driver is installed separately from the Python SDK packages, so after upgrading the SDK you must also bring the driver up to that SDK's minimum — 1.6.2 for SDK 1.8. Nothing checks this at install time, and a driver below the minimum leaves the device unavailable: `axdevice` reports the version required and fails to open the device.

    ```text
    [libaxldev.c:285] Found kernel driver version 1.5.5, but at least version 1.6.2 is required. Please update the kernel driver
    ERROR: AXR_ERROR_CONNECTION_ERROR: Failed to open device metis-0:4:0
    ```

    See also [Step 3: Install the Metis kernel driver](https://docs.axelera.ai/sdk/user-guides/sdk-install#step-3-install-the-metis-kernel-driver). If you are already running an earlier SDK on Ubuntu, update the driver and reload the kernel module (no reboot required):

    ```bash
    sudo apt update
    sudo apt install -y metis-dkms
    sudo rmmod metis
    sudo modprobe metis
    ```

    Then re-run `axdevice` to confirm the device is detected.

!!! tip "First run downloads the SDK automatically"

    The first `yolo export format=axelera` or `yolo predict` with an Axelera model will automatically download and install the Axelera SDK packages. This may take several minutes depending on your connection speed, and no progress is shown during the download. To install manually beforehand:

    ```bash
    pip install axelera-devkit==1.8.0 --extra-index-url https://software.axelera.ai/artifactory/api/pypi/axelera-pypi/simple
    pip install axelera-rt==1.8.0 --extra-index-url https://software.axelera.ai/artifactory/api/pypi/axelera-pypi/simple
    ```

!!! warning "An SDK upgrade invalidates existing exported models"

    SDK 1.8 raises the compiled `.axm` model format version, so `_axelera_model` directories produced by an earlier SDK are rejected at load time. Re-export each model after upgrading:

    ```text
    Error: Unsupported model version: 4.0, expected at least 5.0
    Please re-deploy or re-download the model.
    ```

## Exporting YOLO Models to Axelera

The Axelera format supports the [Export](../modes/export.md), [Predict](../modes/predict.md), and [Validate](../modes/val.md) modes. Inference and validation run on Axelera Metis AIPU hardware. Export your model, then load the exported model to run inference or validate its accuracy.

!!! example "Export"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load a YOLO26 model
        model = YOLO("yolo26n.pt")

        # Export the model to Axelera format
        model.export(format="axelera")  # creates 'yolo26n_axelera_model'
        ```

    === "CLI"

        ```bash
        # Export a YOLO26n PyTorch model to Axelera format
        yolo export model=yolo26n.pt format=axelera # creates 'yolo26n_axelera_model'
        ```

!!! example "Predict"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load the exported Axelera model
        model = YOLO("yolo26n_axelera_model")

        # Run inference
        results = model("https://ultralytics.com/images/bus.jpg")
        ```

    === "CLI"

        ```bash
        # Run inference with the exported Axelera model
        yolo predict model=yolo26n_axelera_model source='https://ultralytics.com/images/bus.jpg'
        ```

!!! example "Validate"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load the exported Axelera model
        model = YOLO("yolo26n_axelera_model")

        # Validate accuracy on the COCO8 dataset
        metrics = model.val(data="coco8.yaml")
        ```

    === "CLI"

        ```bash
        # Validate the exported Axelera model
        yolo val model=yolo26n_axelera_model data=coco8.yaml
        ```

### Export Arguments

| Argument   | Type                      | Default     | Description                                                                                                                                                                                                          |
| :--------- | :------------------------ | :---------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `format`   | `str`                     | `'axelera'` | Target format for Axelera Metis AIPU hardware.                                                                                                                                                                       |
| `imgsz`    | `int` or `tuple`          | `640`       | Image size for model input.                                                                                                                                                                                          |
| `batch`\*  | `int`                     | `1`         | Specifies export model batch inference size or the max number of images the exported model will process concurrently in `predict` mode.                                                                              |
| `quantize` | `int` or `str`            | `8`/auto    | Quantization precision. `8` (INT8) is required and auto-enabled for the Axelera AIPU. Replaces the deprecated `half`/`int8` flags. See [INT8 quantization](https://www.ultralytics.com/glossary/model-quantization). |
| `data`     | `str`                     | `None`      | Calibration dataset YAML; classification instead takes a dataset directory or a built-in dataset name. If omitted, Ultralytics selects a task-specific calibration dataset.                                          |
| `fraction` | `float`, `int`, or `list` | `1.0`       | Calibration subset as a ratio, image count, or `[train, val, test]` ratios/counts. Two-item lists leave `test` full, while `0` skips it (100-400 images recommended).                                                |
| `device`   | `str`                     | `None`      | Export device: GPU (`device=0`) or CPU (`device=cpu`).                                                                                                                                                               |

\* Inference with `batch>1` requires Voyager SDK 1.8.0 or newer; models are compiled for a single image.

For all export options, see the [Export Mode documentation](../modes/export.md).

### Output Structure

```text
yolo26n_axelera_model/
├── yolo26n.axm                  # Axelera model file
├── compiler_config_final.toml  # Compiler configuration used for the build
└── metadata.yaml               # Model metadata (classes, image size, etc.)
```

## Axelera AI Benchmarks

The Metis AIPU maximizes throughput while minimizing energy consumption.

| Model   | Metis PCIe FPS (frames per second) | Metis M.2 FPS (frames per second) |
| ------- | ---------------------------------- | --------------------------------- |
| YOLOv8n | 847                                | 771                               |
| YOLO11n | 746                                | 574                               |
| YOLO26n | 648.6                              | 484.9                             |

_Benchmarks based on Axelera AI data. Actual FPS depends on model size, batching, and input resolution._

These are host throughput figures, measured by the [model zoo](https://docs.axelera.ai/sdk/reference/models/model-zoo) with the Voyager SDK's streaming pipeline over a 720p video file. A single `predict` call reports per-image latency instead, which is a different quantity.

## Real-World Applications

Ultralytics YOLO on Axelera hardware enables advanced edge computing solutions:

- **Smart Retail**: Real-time [object counting](../guides/object-counting.md) and [heatmap analytics](../guides/heatmaps.md) for store optimization.
- **Industrial Safety**: Low-latency [PPE detection](../datasets/detect/construction-ppe.md) in manufacturing environments.
- **Drone Analytics**: High-speed [object detection](../tasks/detect.md) on UAVs for [agriculture](https://www.ultralytics.com/solutions/computer-vision-in-agriculture) and search-and-rescue.
- **Traffic Systems**: Edge-based [license plate recognition](https://www.ultralytics.com/blog/using-ultralytics-yolo11-for-automatic-number-plate-recognition) and [speed estimation](../guides/speed-estimation.md).

## Recommended Workflow

1. **Train** your model using Ultralytics [Train Mode](../modes/train.md)
2. **Export** to Axelera format using `model.export(format="axelera")`
3. **Validate** accuracy with `yolo val` to verify minimal quantization loss
4. **Predict** using `yolo predict` for qualitative validation
5. **Deploy** to a high-performance end-to-end pipeline without PyTorch dependency — see the [YOLO on Voyager SDK examples](https://github.com/ultralytics/ultralytics/tree/main/examples/YOLO-Axelera-Python) for composable Python pipelines using `axelera-rt`

## Device Health Check

Verify your Axelera device is functioning properly:

```bash
# if axdevice cannot be found, please run at least one inference (see above) to ensure the required packages are installed
axdevice
```

For detailed diagnostics, see the [AxDevice documentation](https://docs.axelera.ai/sdk/reference/tools/axdevice/).

## Maximum Performance

Models are compiled for a single image. Passing several images to [Predict](../modes/predict.md) routes them through the Axelera scheduler (Voyager SDK 1.8 or newer), so `batch>1` runs correctly, though measured end to end on a single device it is no faster than `batch=1`:

```bash
yolo predict model=yolo26n_axelera_model source=path/to/images batch=8
```

For production requiring maximum throughput, the [Axelera Voyager SDK](https://github.com/axelera-ai-hub/voyager-sdk) offers:

- Streaming inference pipelines that keep several frames in flight
- Compiling one model across several cores
- Tiled inferencing for higher-resolution cameras

See the [model-zoo](https://docs.axelera.ai/sdk/reference/models/model-zoo) for FPS benchmarks or [contact Axelera](https://axelera.ai/contact-us) for production support.

## Known Issues

!!! warning "Known Limitations"

    - **M.2 power limitations**: Large or extra-large models may encounter runtime errors on M.2 accelerators due to power supply constraints.

For support, visit the [Axelera Community](https://community.axelera.ai/).

## FAQ

### What YOLO versions are supported on Axelera?

The Voyager SDK supports export of [YOLOv8](../models/yolov8.md), [YOLO11](../models/yolo11.md), and [YOLO26](../models/yolo26.md) models. See [Supported Tasks](#supported-tasks) for per-model task availability.

### Can I deploy custom-trained models?

Yes. Any model trained using [Ultralytics Train Mode](../modes/train.md) can be exported to the Axelera format, provided it uses supported layers and operations.

### How does INT8 quantization affect accuracy?

Axelera's Voyager SDK automatically quantizes models for the mixed-precision AIPU architecture. For most [object detection](https://www.ultralytics.com/glossary/object-detection) tasks, the performance gains (higher FPS, lower power) significantly outweigh the minimal impact on [mAP](../guides/yolo-performance-metrics.md). Quantization takes seconds to several hours depending on model size. Run `yolo val` after export to verify accuracy.

### How many calibration images should I use?

We recommend 100 to 400 images. More than 400 provides no additional benefit and increases quantization time. Experiment with 100, 200, and 400 images to find the optimal balance.

### Where can I find the Voyager SDK?

The SDK, drivers, and compiler tools are available via the [Axelera Developer Portal](https://github.com/axelera-ai-hub/voyager-sdk).
