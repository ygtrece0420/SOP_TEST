---
plans: [free, pro, enterprise]
title: Cloud Model Training
comments: true
description: Learn about model training in Ultralytics Platform including project organization, cloud training, and real-time metrics streaming.
keywords: Ultralytics Platform, model training, cloud training, YOLO, GPU training, machine learning, deep learning
---

# Model Training

[Ultralytics Platform](https://platform.ultralytics.com) provides comprehensive tools for [training YOLO models](../../modes/train.md), from organizing experiments to running cloud training jobs with real-time metrics streaming.

<p align="center">
  <br>
  <iframe loading="lazy" width="720" height="405" src="https://www.youtube.com/embed/bajkq0NrSN8"
    title="YouTube video player" frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    allowfullscreen>
  </iframe>
  <br>
  <strong>Watch:</strong> Get Started with Ultralytics Platform - Train
</p>

## Overview

The Training section helps you:

- **Organize** models into [projects](projects.md) for easier management
- **Train** on cloud GPUs with a single click
- **Monitor** real-time metrics during training
- **Compare** model performance across experiments
- **Export** to 20 deployment formats (see [supported formats](models.md#supported-formats))

![Ultralytics Platform Train Overview](https://cdn.ul.run/i/4ec82b7ca5d7c33caab98e08da93ea05.avif)<!-- screenshot -->

## Workflow

```mermaid
graph LR
    A[📁 Project]:::start --> B[⚙️ Configure]:::proc
    B --> C[🚀 Train]:::proc
    C --> D[📈 Monitor]:::proc
    D --> E[📦 Export]:::out

    classDef start fill:#4CAF50,color:#fff
    classDef proc fill:#2196F3,color:#fff
    classDef out fill:#9C27B0,color:#fff
```

| Stage         | Description                                                                |
| ------------- | -------------------------------------------------------------------------- |
| **Project**   | Create a workspace to organize related models                              |
| **Configure** | Select [dataset](../data/datasets.md), base model, and training parameters |
| **Train**     | Run on cloud GPUs or your local hardware                                   |
| **Monitor**   | View real-time loss curves and metrics                                     |
| **Export**    | Convert to 20 deployment formats ([details](models.md#supported-formats))  |

## Training Options

Ultralytics Platform supports multiple training approaches:

| Method                                                  | Description                                   | Best For                   |
| ------------------------------------------------------- | --------------------------------------------- | -------------------------- |
| **[Cloud Training](cloud-training.md)**                 | Train on Ultralytics Cloud GPUs               | No local GPU, scalability  |
| **[Local Training](cloud-training.md#remote-training)** | Train locally, stream metrics to the platform | Existing hardware, privacy |
| **[Colab Training](cloud-training.md#remote-training)** | Use Google Colab with platform integration    | Free GPU access            |

!!! tip "Automatic GPU Routing"

    When you select a GPU cheaper than the RTX PRO 6000 and Ultralytics-managed capacity is free, the Platform runs
    your job on an RTX PRO 6000 while still billing your selected GPU's hourly rate. Runs can finish sooner and cost
    less than they would have on the selected GPU — the upgrade never adds time or cost.

## GPU Options

Available GPUs for cloud training on Ultralytics Cloud:

{% include "macros/platform-gpu-table.md" %}

!!! info "GPU Tier Access"

    B200 and B300 GPUs require a [Pro or Enterprise plan](../account/billing.md#plans). All other GPUs are available on all plans including Free.

!!! tip "Signup Credits"

    New accounts receive signup credits for training. Check [Billing](../account/billing.md) for details.

## Real-Time Metrics

During training, view live metrics across three subtabs:

```mermaid
graph LR
    A[Charts]:::start --> B[Loss Curves]:::out
    A --> C[Task Metrics]:::out
    D[Console]:::start --> E[Live Logs]:::out
    D --> F[Error Detection]:::out
    G[System]:::start --> H[GPU, CPU & Memory]:::out
    G --> I[Network & Disk I/O]:::out

    classDef start fill:#4CAF50,color:#fff
    classDef out fill:#9C27B0,color:#fff
```

| Subtab      | Metrics                                                                                          |
| ----------- | ------------------------------------------------------------------------------------------------ |
| **Charts**  | Task metrics (mAP50, mAP50-95, precision, recall for detection), train/val losses, learning rate |
| **Console** | Live training logs with ANSI color and automatic error detection                                 |
| **System**  | GPU utilization, GPU memory and temperature, CPU, RAM, network and disk I/O                      |

!!! info "Automatic Checkpoints"

    The best checkpoint (`best.pt`, the highest-fitness epoch) is uploaded to the Platform periodically **while
    training runs** and again when the run ends, so download, export, and deployment always use the best epoch
    produced so far. Cancelled runs keep the last checkpoint that finished uploading.

## Quick Start

Get started with cloud training in under a minute:

=== "Cloud (UI)"

    1. Create a project in the sidebar
    2. Click **New Model**
    3. Select a model, dataset, and GPU
    4. Click **Start Training**

=== "Remote (CLI)"

    ```bash
    export ULTRALYTICS_API_KEY="YOUR_API_KEY"
    yolo train model=yolo26n.pt data=ul://username/datasets/my-dataset \
      epochs=100 project=username/my-project name=exp1
    ```

=== "Remote (Python)"

    ```python
    from ultralytics import YOLO

    model = YOLO("yolo26n.pt")
    model.train(
        data="ul://username/datasets/my-dataset",
        epochs=100,
        project="username/my-project",
        name="exp1",
    )
    ```

## Quick Links

- [**Projects**](projects.md): Organize your models and experiments
- [**Models**](models.md): Manage trained checkpoints
- [**Cloud Training**](cloud-training.md): Train on cloud GPUs
- [**AutoTrain**](autotrain.md): Use Ask AI to run experiments and compare models

## FAQ

### How long does training take?

Training time depends on:

- Dataset size (number of images)
- Model size (n, s, m, l, x)
- Number of epochs
- GPU type selected

The current estimator predicts about 6 minutes for 1000 images, YOLO26n, 100 epochs on RTX PRO 6000, and about 2
minutes for 500 images, YOLO26n, 50 epochs on RTX 4090. Actual duration varies; use the live estimate in the training
dialog for the selected dataset and configuration. See [cost examples](cloud-training.md#cost-examples).

### Can I train multiple models simultaneously?

Yes. Concurrent cloud training limits depend on your plan: Free allows 3, Pro allows 10, and Enterprise is unlimited. For additional parallel training, use remote training from multiple machines.

### What happens if training fails?

If training fails:

1. The model is marked failed and the compute instance is terminated
2. The model page shows an error banner with the captured error, a link to the console output, and a **Retry**
   action that reopens the training dialog with the same configuration
3. A run that stops reporting activity for several hours is automatically marked failed and its compute released
4. If cloud compute had started, elapsed GPU time is charged; failures before compute starts have no GPU usage charge

### How do I choose the right GPU?

| Scenario                      | Recommended GPU  |
| ----------------------------- | ---------------- |
| Most training jobs            | RTX PRO 6000     |
| Large datasets or batch sizes | H100 SXM or H200 |
| Budget-conscious              | RTX 4090         |
