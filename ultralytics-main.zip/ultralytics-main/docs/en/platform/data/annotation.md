---
plans: [free, pro, enterprise]
comments: true
description: Learn to annotate images in Ultralytics Platform with manual tools, skeleton templates for pose estimation, and Smart annotation with SAM and YOLO models for detect, segment, semantic, and OBB tasks.
keywords: Ultralytics Platform, annotation, labeling, SAM, auto-annotation, bounding box, polygon, keypoints, skeleton templates, pose estimation, segmentation, YOLO
---

# Annotation Editor

[Ultralytics Platform](https://platform.ultralytics.com) includes an annotation editor for labeling images with bounding boxes, polygons, keypoints, oriented boxes, and classifications. The editor supports manual drawing, [SAM-powered smart annotation](https://www.ultralytics.com/annotate), and predictions from compatible YOLO models.

![Ultralytics Platform Annotate Editor Toolbar With Canvas](https://cdn.ul.run/i/fd13a4b1f4b8fad9ed5e736030a070cf.avif)<!-- screenshot -->

```mermaid
graph TB
    subgraph Draw["Shape set by the dataset task"]
        A[Box]:::start & B[Polygon]:::start & C[Classify]:::start & D[Keypoint]:::start & E[OBB]:::start
    end
    subgraph AI["AI-Assisted"]
        F[SAM Smart]:::start
        G[YOLO Predict]:::start
    end
    Draw --> H[Save Labels]:::out
    AI --> H

    classDef start fill:#4CAF50,color:#fff
    classDef out fill:#9C27B0,color:#fff
```

## Supported Task Types

The annotation editor provides annotation tools for 6 YOLO task types:

| Task                                             | Tool           | Annotation Format                                         |
| ------------------------------------------------ | -------------- | --------------------------------------------------------- |
| **[Detect](../../datasets/detect/index.md)**     | Rectangle      | Bounding boxes (x, y, width, height)                      |
| **[Segment](../../datasets/segment/index.md)**   | Polygon        | Pixel-precise masks (polygon vertices)                    |
| **[Semantic](../../datasets/semantic/index.md)** | Polygon        | Per-class region masks (polygon vertices)                 |
| **[Classify](../../datasets/classify/index.md)** | Class Selector | Image-level labels                                        |
| **[Pose](../../datasets/pose/index.md)**         | Keypoint       | Skeleton templates (Person, Hand, Dog, Face, Box, custom) |
| **[OBB](../../datasets/obb/index.md)**           | Oriented Box   | Rotated bounding boxes (4 corners)                        |

!!! tip "Multi-Task Annotations"

    All 6 annotation types are stored together on each image. You can switch the dataset's active task type without losing existing annotations — they are preserved and reappear when you switch back.

[Depth ground truth](../../datasets/depth/index.md#depth-map-format) is a paired map you upload, not something you draw, so the editor opens read-only on a depth dataset.

### Task Details

??? info "Object Detection"

    **What it does:** Identifies objects and their locations with axis-aligned bounding boxes.

    **Label format:** [`class_id center_x center_y width height`](../../datasets/detect/index.md#ultralytics-yolo-format) (all normalized 0-1)

    **Example:** `0 0.5 0.5 0.2 0.3` — Class 0 centered at (50%, 50%) with 20% width and 30% height

    **Use cases:** Inventory counting, traffic monitoring, wildlife detection, security systems

??? info "Instance Segmentation"

    **What it does:** Creates pixel-precise masks for each object instance.

    **Label format:** [`class_id x1 y1 x2 y2 x3 y3 ...`](../../datasets/segment/index.md#ultralytics-yolo-format) (polygon vertices, normalized 0-1)

    **Example:** `0 0.1 0.1 0.9 0.1 0.9 0.9 0.1 0.9` — Quadrilateral mask

    **Use cases:** Medical imaging, autonomous vehicles, photo editing, agricultural analysis

??? info "Pose Estimation"

    **What it does:** Detects body keypoints for skeleton tracking.

    **Label format:** [`class_id cx cy w h kx1 ky1 v1 kx2 ky2 v2 ...`](../../datasets/pose/index.md#ultralytics-yolo-format)

    - Visibility flags: `0`=not labeled, `1`=labeled but occluded, `2`=labeled and visible

    **Example:** `0 0.5 0.5 0.2 0.3 0.6 0.7 2 0.4 0.8 1` — Person with 2 keypoints

    **Use cases:** Sports analysis, physical therapy, animation, gesture recognition

??? info "Oriented Bounding Box (OBB)"

    **What it does:** Detects rotated objects with angle-aware bounding boxes.

    **Label format:** [`class_id x1 y1 x2 y2 x3 y3 x4 y4`](../../datasets/obb/index.md#yolo-obb-format) (four corner points, normalized)

    **Example:** `0 0.1 0.1 0.9 0.1 0.9 0.9 0.1 0.9` — Rotated rectangle

    **Use cases:** Aerial imagery, document analysis, manufacturing inspection, ship detection

??? info "Image Classification"

    **What it does:** Assigns a single label to the entire image.

    **Label format:** [Folder-based](../../datasets/classify/index.md#dataset-structure-for-yolo-classification-tasks) — images organized by class name (`train/cats/`, `train/dogs/`)

    **Use cases:** Content moderation, quality control, medical diagnosis, scene recognition

## Getting Started

To annotate images:

1. Navigate to your dataset
2. Click an image once to open the fullscreen annotation editor
3. Use the default `Draw` mode, or switch to `Smart` where supported
4. Select a class and add or adjust annotations directly on the image
5. Continue to another image or close the editor; changes save automatically after each edit

For datasets you can edit, annotation controls are active as soon as the fullscreen viewer opens on desktop. There is no separate edit mode or `Edit` button. On mobile, and when you do not have edit access, the fullscreen viewer is read-only.

![Ultralytics Platform Fullscreen Annotation Editor With Toolbar](https://cdn.ul.run/i/96b05b3e135932d5a49ba8c0ad05d0b8.avif)<!-- screenshot -->

```mermaid
graph LR
    A[Open Dataset]:::start --> B[Click Image]:::proc
    B --> C[Annotate in Fullscreen]:::proc
    C --> D[Changes Auto-Save]:::out
    D --> E[Next Image]:::proc
    E --> B

    classDef start fill:#4CAF50,color:#fff
    classDef proc fill:#2196F3,color:#fff
    classDef out fill:#9C27B0,color:#fff
```

## Annotation Modes

`Draw` is the default mode for spatial annotation tasks. For detect, segment, semantic, and OBB datasets, the toolbar also provides `Smart` mode when Smart annotation is available:

| Mode      | Description                                                                 | Shortcut |
| --------- | --------------------------------------------------------------------------- | -------- |
| **Draw**  | Default manual mode with task-specific drawing tools                        | `V`      |
| **Smart** | SAM or YOLO model-assisted annotation (detect, segment, semantic, OBB only) | `S`      |

Pose annotation uses `Draw` with a skeleton template — the `Smart` button appears but is disabled and marked "Coming Soon". Classification uses the class sidebar directly and shows no drawing toolbar or `Smart` button at all.

Smart annotation is not currently available for [connected datasets](../integrations/index.md) backed by cloud or On Premise storage.

## Draw Mode Tools

### Bounding Box (Detect)

Draw rectangular boxes around objects:

1. Select a class in the class sidebar
2. In the default `Draw` mode, click and drag to draw a rectangle
3. Release to complete the box

![Ultralytics Platform Annotate Detect Bounding Box Drawing](https://cdn.ul.run/i/03f7437fabd12653415375312874950c.avif)<!-- screenshot -->

!!! tip "Resize and Move"

    - Drag 8 corner/edge handles to resize
    - Drag the center to move
    - Press `Delete` or `Backspace` to remove selected annotation

### Polygon (Segment)

Draw precise polygon masks:

1. Select a class in the class sidebar
2. In the default `Draw` mode, click to add vertices, or hold `Shift` and move the mouse to freehand-draw dense points
3. Double-click, click the first vertex, or press `Enter` or `Escape` to close the polygon

![Ultralytics Platform Annotate Segment Polygon Vertices](https://cdn.ul.run/i/be5cf764c0b8a32158064b352934cdff.avif)<!-- screenshot -->

!!! tip "Edit Vertices"

    - Drag individual vertices to adjust
    - Drag the entire polygon to move
    - Click on a vertex and press `Delete` to remove it

### Keypoint (Pose)

Annotate poses using skeleton templates. Select a template from the toolbar, click once to place all keypoints, then drag individual keypoints to adjust positions.

1. Select a class in the class sidebar
2. In the default `Draw` mode, choose a skeleton template from the template picker in the toolbar
3. Click on the image to place all keypoints at once
4. Drag individual keypoints to adjust their positions

![Ultralytics Platform Annotate Pose Template Dropdown](https://cdn.ul.run/i/baef28c5d70d64d970d35496f4326f5e.avif)<!-- screenshot -->

#### Built-in Skeleton Templates

The editor includes 5 built-in templates:

| Template   | Keypoints | Description                                                                                                            |
| ---------- | --------- | ---------------------------------------------------------------------------------------------------------------------- |
| **Person** | 17        | [COCO human body pose](../../datasets/pose/coco.md) — nose, eyes, ears, shoulders, elbows, wrists, hips, knees, ankles |
| **Hand**   | 21        | [Ultralytics Hand Keypoints](../../datasets/pose/hand-keypoints.md) — wrist, thumb, index, middle, ring, pinky joints  |
| **Dog**    | 18        | AP-10K animal pose — nose, head, neck, shoulders, tailbase, tail, and 4 legs (elbows, knees, paws)                     |
| **Face**   | 68        | iBUG 300W facial landmarks — jaw, eyebrows, nose, eyes, mouth                                                          |
| **Box**    | 4         | Corner keypoints — top-left, top-right, bottom-right, bottom-left                                                      |

![Ultralytics Platform Annotate Pose Keypoints Skeleton](https://cdn.ul.run/i/d23341102121bd297eda4762674133e4.avif)<!-- screenshot -->

#### Custom Skeleton Templates

Create custom templates for any pose structure:

1. Click the **+** button next to the template picker
2. Optionally, click **Start from...** to load keypoints and connections from an existing template as a starting point
3. Place keypoints on the canvas by clicking
4. Name each keypoint and customize colors
5. Connect keypoints by selecting two points (connections are drawn automatically as you place sequential keypoints)
6. Save the template for reuse across your dataset

![Ultralytics Platform Annotate Pose Custom Template](https://cdn.ul.run/i/17471f496ec024a8b1db75ac99d1bc09.avif)<!-- screenshot -->

Custom templates are saved to your account and available in all pose datasets.

!!! tip "Template Workflow"

    The template system replaces manual sequential keypoint placement. Instead of clicking 17 times for a COCO skeleton, select the Person template and click once — all keypoints are placed in the correct skeleton layout. Then drag to adjust positions for the specific pose.

!!! info "Keypoint Visibility"

    Each keypoint has a visibility flag: `0` = not labeled, `1` = labeled but occluded, `2` = labeled and visible. Occluded keypoints (behind other objects) should be marked with visibility `1` — the model learns to infer their position.

### Oriented Bounding Box (OBB)

Draw rotated boxes for angled objects:

1. Select a class in the class sidebar
2. In the default `Draw` mode, click and drag to draw an initial box
3. Use the rotation handle to adjust angle
4. Drag corner handles to resize

![Ultralytics Platform Annotate Obb Rotated Box](https://cdn.ul.run/i/f7bd3dc0bc310162c5841659eed55b72.avif)<!-- screenshot -->

### Classification (Classify)

Assign image-level class labels:

1. Click an image to open the fullscreen editor
2. Select a class in the class sidebar, or press a number key from `1-9`

![Ultralytics Platform Annotate Classify Side Panel](https://cdn.ul.run/i/aee8d1a82873672bf6d179df35e5d939.avif)<!-- screenshot -->

## Smart Annotation

Smart annotation adds model-assisted annotation to the editor. In Smart mode, you can use [Segment Anything Model (SAM)](../../models/sam.md) for click-based annotation or use pretrained Ultralytics YOLO models and your own fine-tuned YOLO models to add predictions as annotations. Smart annotation is available for **detect**, **segment**, **semantic**, and **OBB** tasks.

### SAM Smart Annotation

With a SAM model selected:

1. Select `Smart` or press `S`
2. Click on the object you want to annotate — SAM generates an initial mask in real-time
3. Refine the mask with additional clicks: click **outside** the current mask to add coverage, or click **inside** the current mask to subtract regions
4. Press `Enter` or `Escape` to save the annotation, or enable **auto-apply** for one-click workflows

![Ultralytics Platform Annotate Sam Positive Negative Points Mask](https://cdn.ul.run/i/b91475227406a0f3a596d3b5e200f39c.avif)<!-- screenshot -->

```mermaid
graph LR
    A[Press S]:::start --> B[Left-click Object]:::proc
    B --> C[SAM Generates Mask]:::proc
    C --> D{Auto-apply?}:::decide
    D -->|Yes| E[Mask Applied Automatically]:::out
    D -->|No| F{Accurate?}:::decide
    F -->|Yes| G[Enter to Save]:::out
    F -->|No| H[Add +/- Points]:::proc
    H --> C

    classDef start fill:#4CAF50,color:#fff
    classDef proc fill:#2196F3,color:#fff
    classDef decide fill:#FF9800,color:#fff
    classDef out fill:#9C27B0,color:#fff
```

!!! tip "SAM Tips"

    - Start with a click on the object center
    - Click again outside the mask to expand coverage
    - Click inside the mask to subtract unwanted regions
    - Enable **auto-apply** (`A`) for one-click annotation
    - Hold `Shift` while auto-apply is on to place multiple points before the mask is applied
    - Works best for distinct objects with clear edges
    - Use a few refinement clicks for elongated or overlapping objects

SAM smart annotation can generate:

- **Polygons** for segmentation tasks
- **Bounding boxes** for detection tasks
- **Oriented boxes** for OBB tasks

!!! warning "SAM Task Support"

    SAM smart annotation is only available for **detect**, **segment**, **semantic**, and **OBB** tasks. Pose and classification require manual annotation.

#### Auto-Apply Mode

Auto-apply mode speeds up Smart annotation by automatically saving the SAM mask after each click — no need to press `Enter`. Toggle it with the auto-apply button in the toolbar or press `A`.

| Mode                         | Behavior                                             |
| ---------------------------- | ---------------------------------------------------- |
| **Auto-apply ON**            | Mask applies automatically after each click          |
| **Auto-apply ON + `Shift`**  | Place multiple points first, mask applies on release |
| **Auto-apply OFF** (default) | Place points freely, press `Enter` to apply          |

![Ultralytics Platform Annotate Sam Auto Apply Toggle](https://cdn.ul.run/i/f58a86dfc093bd70d95901a53d7b0851.avif)<!-- screenshot -->

!!! tip "When to Use Auto-Apply"

    Auto-apply is ideal for datasets with well-separated objects where a single click produces an accurate mask. For complex or overlapping objects, turn auto-apply off and use multiple positive/negative points to refine the mask before saving.

#### SAM Model Selection

When Smart mode is active, a model picker appears in the toolbar. Six SAM models are available — choose based on the speed vs. accuracy trade-off that suits your dataset:

| Model             | Size    | Speed    | Notes                      |
| ----------------- | ------- | -------- | -------------------------- |
| **SAM 2.1 Tiny**  | 75 MB   | Fastest  |                            |
| **SAM 2.1 Small** | 88 MB   | Fast     |                            |
| **SAM 2.1 Base**  | 154 MB  | Moderate |                            |
| **SAM 2.1 Large** | 428 MB  | Slower   | Most accurate of SAM 2.1   |
| **SAM 3**         | 3.45 GB | Slowest  |                            |
| **SAM 3.1**       | 3.50 GB | Slowest  | Default, latest generation |

![Ultralytics Platform Annotate Sam Model Selector](https://cdn.ul.run/i/88703961af233af7fe5ddf35ff8a5f96.avif)<!-- screenshot -->

Switching models while Smart mode is active re-initializes the predictor for the current image automatically.

### YOLO Smart Annotation

With a YOLO model selected, Smart annotation can add predictions from pretrained Ultralytics models or your own fine-tuned models.

1. Select `Smart` or press `S`
2. Select a YOLO model from the model picker in the toolbar (`Official` or `My Models`)
3. Click `Predict`
4. Review the added annotations and make any needed corrections

![Ultralytics Platform Annotate Smart Annotation Yolo Model](https://cdn.ul.run/i/5340dc36ed1da9a4804c4fc8ec5c4552.avif)<!-- screenshot -->

!!! tip "YOLO Model Notes"

    - The model picker only lists models that match the current dataset task.
    - Duplicate predictions are skipped when they overlap an existing annotation of the same class at IoU `0.7` or higher.

## Class Sidebar

The annotation editor includes a collapsible class sidebar on the right side of the canvas. The sidebar provides:

- **Search classes**: Filter the class list by typing in the search field. Press `Enter` on an exact match to select it, or create a new class if no match exists.
- **Create new class inline**: Click `Add class` at the bottom of the list, type a name, and optionally pick a custom color. Press `Enter` to create.
- **Edit class name inline**: Hover over a class name and click the pencil icon to rename it.
- **Color picker**: Click the color swatch next to any class to change its color.
- **Per-class annotation count**: Each class row shows a superscript count of annotations.
- **Expand/collapse**: Click the chevron to expand a class and see individual annotations listed below it.
- **Bidirectional hover highlighting**: Hovering an annotation on the canvas highlights it in the sidebar, and vice versa. The sidebar auto-scrolls to the relevant class.
- **Hide/show a whole class**: Click the eye icon on a class row to hide or show every annotation of that class at once.
- **Hide/show individual annotations**: Click the eye icon on any annotation row to toggle its visibility on the canvas.
- **Delete annotations**: Click the trash icon on any annotation row to delete it.
- **Keyboard shortcuts**: Press `1-9` to quickly select the first 9 classes, or `H` to toggle the visibility of every annotation on the image.

## Context Menu

Right-click on selected annotations to open a context menu with:

| Action               | Shortcut               |
| -------------------- | ---------------------- |
| Delete Annotation(s) | `Delete` / `Backspace` |
| Bring to Front       | `Cmd/Ctrl+Shift+]`     |
| Send to Back         | `Cmd/Ctrl+Shift+[`     |
| Bring Forward        | `Cmd/Ctrl+]`           |
| Send Backward        | `Cmd/Ctrl+[`           |

## Visibility Controls

The visibility dropdown (eye icon) lets you toggle display of individual elements:

| Toggle              | Description                                                                                                     |
| ------------------- | --------------------------------------------------------------------------------------------------------------- |
| **Annotations**     | Show or hide all annotation overlays                                                                            |
| **Class labels**    | Show or hide class name labels on annotations                                                                   |
| **Show pixels**     | Toggle pixelated rendering for zoom inspection (fullscreen)                                                     |
| **Crosshairs**      | Show crosshair cursor with pixel coordinates while annotating                                                   |
| **Nav thumbnails**  | Show navigation thumbnail strip (fullscreen)                                                                    |
| **Bottom info bar** | Show or hide the image info bar at the bottom (fullscreen)                                                      |
| **Show all**        | Toggle annotations, labels, crosshairs, thumbnails, and the bottom info bar at once (does not affect pixelated) |

## Crosshair Cursor

While annotating, a crosshair overlay tracks the cursor position and displays pixel coordinates on the canvas. This helps place annotations with precision. Toggle it via the visibility dropdown.

## SAM Hover Preview

In Smart mode, SAM provides a real-time hover preview before you click any points. This preview is available for **detect**, **segment**, **semantic**, and **OBB** tasks. Once you add refinement clicks, the preview updates to reflect the current mask and the annotation type for the active task.

## Polygon Vertex Editing

For segment annotations, you can edit polygon vertices after drawing:

- **Move vertices**: Drag any vertex handle to reposition it
- **Delete vertices**: Select a vertex and press `Delete` to remove it

## Class Management

### Creating Classes

Define annotation classes for your dataset in the `Classes` tab:

1. Navigate to the `Classes` tab
2. Use the input field at the bottom to type a class name
3. Click `Add` or press `Enter`
4. A color is assigned automatically from the Ultralytics palette

![Ultralytics Platform Annotate Classes Tab Add New Class](https://cdn.ul.run/i/103c2683f43dbbbc4997faf6959c8315.avif)<!-- screenshot -->

### Add New Class During Annotation

You can create new classes directly while annotating without leaving the editor:

1. Draw an annotation on the image
2. In the class sidebar, click `Add class` (or type a new name in the sidebar search box)
3. Enter the class name
4. Press Enter to create and assign

This allows for a seamless workflow where you can define classes as you encounter new object types in your data.

!!! tip "Unified Classes Table"

    All classes across your dataset are managed in a unified table. Changes to class names or colors apply throughout the entire dataset automatically.

### Editing Classes

- **Rename**: Click a class name in the table to edit it inline
- **Change color**: Click the color swatch to open the color picker
- **Search**: Use the search field to filter classes by name
- **Sort**: Click column headers to sort by index, name, annotation count, or image count

### Class Colors

Each class is assigned a color from the Ultralytics palette. You can customize colors using the color picker on the `Classes` tab; the selected colors are used throughout that dataset.

## Keyboard Shortcuts

Efficient annotation with keyboard shortcuts:

=== "General"

    | Shortcut                     | Action                     |
    | ---------------------------- | -------------------------- |
    | `Cmd/Ctrl+S`                 | Save annotations           |
    | `Cmd/Ctrl+Z`                 | Undo                       |
    | `Cmd/Ctrl+Y`                 | Redo                       |
    | `Escape`                     | Save / Deselect / Exit     |
    | `Delete` / `Backspace`       | Delete selected annotation |
    | `Cmd/Ctrl+Delete`            | Delete image               |
    | `H`                          | Toggle all annotations     |
    | `1-9`                        | Select class 1-9           |
    | `Cmd/Ctrl+Scroll`            | Zoom in/out                |
    | `Cmd/Ctrl++` or `Cmd/Ctrl+=` | Zoom in                    |
    | `Cmd/Ctrl+-`                 | Zoom out                   |
    | `Cmd/Ctrl+0`                 | Reset to fit               |
    | `Space+Drag`                 | Pan canvas when zoomed     |
    | `Shift+Click`                | Multi-select annotations   |
    | `Cmd/Ctrl+A`                 | Select all annotations     |
    | `Cmd/Ctrl+C`                 | Copy selected annotations  |
    | `Cmd/Ctrl+X`                 | Cut selected annotations   |
    | `Cmd/Ctrl+V`                 | Paste annotations          |

=== "Modes"

    | Shortcut | Action                         |
    | -------- | ------------------------------ |
    | `V`      | Draw mode (manual, default)    |
    | `S`      | Smart mode (SAM or YOLO model) |

=== "Drawing"

    | Shortcut               | Action                                                                          |
    | ---------------------- | ------------------------------------------------------------------------------- |
    | `Click+Drag`           | Draw bounding box (detect/OBB)                                                  |
    | `Click`                | Add polygon point (segment) / Place skeleton (pose) / Place SAM point (smart)   |
    | `Shift (hold) + Move`  | Freehand draw — continuously adds polygon vertices as the mouse moves           |
    | `Click inside mask`    | Subtract region from SAM mask (negative point)                                  |
    | `Click outside mask`   | Add to SAM mask (positive point)                                                |
    | `Shift (hold) + Click` | Place multiple SAM points before auto-apply commits (Smart mode, auto-apply on) |
    | `A`                    | Toggle auto-apply (Smart mode)                                                  |
    | `P`                    | Run YOLO prediction (Smart mode)                                                |
    | `Enter`                | Complete polygon / Save SAM annotation                                          |
    | `Escape`               | Complete polygon / Save SAM annotation / Deselect / Exit                        |

=== "Arrange (Z-Order)"

    | Shortcut           | Action         |
    | ------------------ | -------------- |
    | `Cmd/Ctrl+]`       | Bring forward  |
    | `Cmd/Ctrl+[`       | Send backward  |
    | `Cmd/Ctrl+Shift+]` | Bring to front |
    | `Cmd/Ctrl+Shift+[` | Send to back   |

![Ultralytics Platform Annotate Keyboard Shortcuts Dialog](https://cdn.ul.run/i/6bb507eae033a53c4181106227895112.avif)<!-- screenshot -->

??? tip "View All Shortcuts"

    Click the keyboard icon in the annotation toolbar to open the shortcuts reference.

## Undo/Redo

The annotation editor maintains a full undo/redo history:

- **Undo**: `Cmd/Ctrl+Z`
- **Redo**: `Cmd/Ctrl+Y`

History tracks:

- Adding annotations (single and batch)
- Editing annotations (move, resize, rotate)
- Deleting annotations (single and batch)
- Changing classes (single and batch)
- Reordering annotations (z-order)
- Editing polygon vertices (add, remove, move)
- Moving keypoints

!!! info "Unlimited Undo"

    The undo stack has no fixed limit — you can undo changes made since you opened the image.

## Saving Annotations

Changes save automatically one second after the last annotation edit. They also save when you move to another image or close the fullscreen editor.

- **Save now**: Click the save button or press `Cmd/Ctrl+S`
- **Close**: Click the close button, click outside the image, or press `Escape`; closing triggers a background save for pending changes

!!! warning "Save Your Work"

    Wait for the `Saving...` or `Unsaved` status in the image information bar to clear before closing the browser tab. You can save manually at any time with the save button or `Cmd/Ctrl+S`.

## FAQ

### How accurate is SAM annotation?

SAM provides high-quality masks for most objects. Accuracy depends on:

- Object distinctiveness from background
- Image quality and resolution
- Number of positive/negative points provided

For best results, start with a click on the object center, then use outside-mask clicks to add coverage and inside-mask clicks to subtract nearby objects or background.

### Can I import existing annotations?

Yes. Upload your dataset with [YOLO-format label files](../../datasets/detect/index.md#ultralytics-yolo-format), COCO JSON annotation files, or an [Ultralytics NDJSON](../../datasets/detect/index.md#ultralytics-ndjson-format) export. Platform parses them during processing and displays them in the editor. Pascal VOC XML labels are not imported — convert them to YOLO or COCO first. See [Preparing Your Dataset](datasets.md#preparing-your-dataset).

### How do I annotate multiple objects of the same class?

After drawing an annotation:

1. Keep the same class selected
2. Draw the next annotation
3. Repeat until all objects are labeled

The keyboard shortcut `1-9` quickly selects classes.

### Can I train on partially annotated datasets?

Yes, but for best results:

- Label all objects of your target classes in each image
- Use the `Annotations` filter set to `Unannotated` to identify images that still need annotation

### Which SAM model should I use?

**SAM 3.1** is the default and the latest generation model — start there for the highest quality masks, with **SAM 3** still available. Switch to **SAM 2.1 Small** for a faster interactive workflow on common objects, or **SAM 2.1 Large** when you need higher mask precision on complex shapes. Use **SAM 2.1 Tiny** for maximum speed on simple, high-contrast objects.

### Which tasks support SAM smart annotation?

SAM smart annotation is available for **detect**, **segment**, **semantic**, and **OBB** tasks. Pose and classification use manual annotation only — on pose datasets the `Smart` button is visible but disabled and marked "Coming Soon". Smart annotation is also unavailable on connected cloud and On Premise datasets.

### Can I create custom skeleton templates for pose annotation?

Yes. Click the **+** button next to the skeleton template picker to open the template editor. Place keypoints, name them, draw connections, and save. Custom templates are stored in your account and available across all pose datasets.

### How do I switch between skeleton templates?

Click the template picker dropdown in the annotation toolbar. Select any built-in template (Person, Hand, Dog, Face, Box) or your saved custom templates. The selected template determines which keypoints are placed when you click on the image.

### Can I copy annotations between images?

Yes. Select one or more annotations, press `Cmd/Ctrl+C` to copy (or `Cmd/Ctrl+X` to cut), navigate to another image with the arrow keys or thumbnail strip, and press `Cmd/Ctrl+V` to paste. The clipboard persists while the fullscreen editor stays open.
