---
plans: [free, pro, enterprise]
comments: true
description: Learn how to recover deleted projects, datasets, and models from Trash on Ultralytics Platform with the 30-day soft delete policy.
keywords: Ultralytics Platform, trash, restore, soft delete, recover, deleted items, data recovery
---

# Trash and Restore

[Ultralytics Platform](https://platform.ultralytics.com) implements a 30-day soft delete policy, allowing you to recover accidentally deleted projects, datasets, and models. Deleted items are moved to Trash where they can be restored before permanent deletion.

![Ultralytics Platform Settings Trash Tab With Items And Storage Treemap](https://cdn.ul.run/i/1fda3fe06d0527f579017b71afa6a2ff.avif)<!-- screenshot -->

## Soft Delete Policy

When you delete a resource on the platform:

1. **Immediate**: Item moves to Trash (not permanently deleted)
2. **30 Days**: Item remains recoverable in Trash
3. **After 30 Days**: Item is permanently deleted automatically

!!! success "Recovery Window"

    You have 30 days to restore any deleted item. After this period, the item and all associated data are permanently removed and cannot be recovered.

## Accessing Trash

Navigate to your Trash:

1. Go to **Settings** and click the **Trash** tab
2. Or navigate directly to `/trash` (redirects to `Settings > Trash`)

![Ultralytics Platform Settings Trash Tab Filter By Type Dropdown](https://cdn.ul.run/i/0590e96caff8724036eb5af5d24fa206.avif)<!-- screenshot -->

## Trash Contents

The Trash shows all soft-deleted resources with filter tabs, each showing a live count, plus a search box that matches
on name and type:

| Filter       | Shows             |
| ------------ | ----------------- |
| **All**      | All trashed items |
| **Datasets** | Trashed datasets  |
| **Projects** | Trashed projects  |
| **Models**   | Trashed models    |

### Viewing Trash Items

Each item in Trash displays:

| Field        | Description                                                                     |
| ------------ | ------------------------------------------------------------------------------- |
| **Name**     | Original resource name                                                          |
| **Type**     | Project, Dataset, or Model (color-coded)                                        |
| **Deleted**  | How long ago the item was deleted                                               |
| **Expires**  | Days until permanent deletion (e.g. "30d"), amber under 15 days and red under 8 |
| **Size**     | Storage used by the item                                                        |
| **Cascaded** | Child items included, shown as a `+N` badge next to the name                    |

(Parent project information is returned by the Trash API for models but is not shown in the Trash table.)

### Cascade Behavior

When deleting a parent resource, child resources are also moved to Trash:

| Resource Type                        | What's Included When Deleted               |
| ------------------------------------ | ------------------------------------------ |
| [**Projects**](../train/projects.md) | Project + all models inside                |
| [**Datasets**](../data/datasets.md)  | Dataset + all images and annotations       |
| [**Models**](../train/models.md)     | Model weights + training history + exports |

!!! note "Active Training Is Cancelled"

    Trashing a model — or a project containing one — cancels any cloud training that model has in progress and
    terminates its GPU instance. Elapsed GPU time is still billed. See
    [Billing](billing.md#training-cost-flow).

### Storage Treemap

The Trash tab includes a storage visualization (treemap) showing the relative size of trashed items, color-coded by type:

- **Blue**: Projects
- **Green**: Datasets
- **Purple**: Models

## Restoring Items

Recover a deleted item (Editor role or higher in a team workspace):

1. Navigate to **Settings > Trash**
2. Find the item you want to restore
3. Click the **Restore** button (undo icon)

![Ultralytics Platform Settings Trash Tab Restore Button On Item](https://cdn.ul.run/i/2dd74fa1d628c9dc2c1bd7581f299976.avif)<!-- screenshot -->

The item returns to its original location with all data intact.

If the original slug is already taken, the platform restores the item with a unique available slug so you can access it immediately.

### Restore Behavior

| Resource | Restore Behavior                                            |
| -------- | ----------------------------------------------------------- |
| Project  | Restores project and all contained models                   |
| Dataset  | Restores dataset with all images and annotations            |
| Model    | Restores model to original project if the project is active |

!!! warning "Parent Project Required"

    Restoring a model fails if its parent project is in Trash. You'll see the error: "Cannot restore model while its parent project is in trash. Restore the project first." Always restore the parent project before restoring individual models.

## Permanent Deletion

### Automatic Deletion

Items in Trash are automatically and permanently deleted after 30 days.

### Empty Trash

Permanently delete all items immediately:

1. Navigate to **Settings > Trash**
2. Click the trash icon in the header
3. Confirm the action

!!! warning "Irreversible Action"

    Emptying Trash permanently deletes all items immediately. This action cannot be undone and all data will be lost, including attached deployments, export jobs, and stored files tied to the trashed resources.

### Delete Single Item Permanently

To permanently delete one item without waiting:

1. Find the item in Trash
2. Click the **Delete permanently** (trash) button on its row
3. Confirm deletion — the dialog names the item and how many cascaded models go with it

For projects, permanent deletion also removes related deployments and export files that belong to the deleted workspace
resources. If a deployment cannot be deleted, the Platform warns you and leaves it
listed on the [Deployments](../deploy/endpoints.md) page so you can retry from there.

## Storage and Trash

Items in Trash still count toward your storage quota:

| Scenario             | Storage Impact                 |
| -------------------- | ------------------------------ |
| Delete item          | Storage remains allocated      |
| Restore item         | No change (was still counting) |
| Permanent deletion   | Storage freed                  |
| 30-day auto-deletion | Storage freed automatically    |

!!! tip "Free Up Storage"

    If you're running low on storage, empty Trash or permanently delete specific items to immediately reclaim space. Check your storage usage in [Settings](settings.md#storage-usage) and see [Billing](billing.md#plans) for plan storage limits.

## API Access

Access trash programmatically via the [REST API](../api/index.md#trash-api). All three operations live on the same
`/api/trash` path and operate on the workspace that issued the API key — to manage a team workspace's trash, use an
API key from that workspace. The Python examples use the [`ultralytics-platform`](../api/index.md#python-sdk) SDK:

```python
from ultralytics_platform import Platform

client = Platform()  # reads ULTRALYTICS_API_KEY
```

=== "List Trash"

    ```bash
    curl -H "Authorization: Bearer YOUR_API_KEY" \
      "https://platform.ultralytics.com/api/trash?type=all&page=1&limit=50"
    ```

    ```python
    trash = client.lifecycle.trash(type="all", page=1, limit=50)
    ```

    `type` accepts `all`, `project`, `dataset`, or `model`. `limit` defaults to 50 and caps at 200. Listing needs
    Viewer access or higher.

=== "Restore Item"

    ```bash
    curl -X POST -H "Authorization: Bearer YOUR_API_KEY" \
      -H "Content-Type: application/json" \
      -d '{"id": "ITEM_ID", "type": "dataset"}' \
      https://platform.ultralytics.com/api/trash
    ```

    ```python
    client.lifecycle.restore(id="ITEM_ID", type="dataset")
    ```

=== "Delete One Item"

    ```bash
    curl -X DELETE -H "Authorization: Bearer YOUR_API_KEY" \
      -H "Content-Type: application/json" \
      -d '{"id": "ITEM_ID", "type": "dataset"}' \
      https://platform.ultralytics.com/api/trash
    ```

    ```python
    client.lifecycle.delete_trash(body={"id": "ITEM_ID", "type": "dataset"})
    ```

=== "Empty Trash"

    ```bash
    curl -X DELETE -H "Authorization: Bearer YOUR_API_KEY" \
      -H "Content-Type: application/json" \
      -d '{"all": true}' \
      https://platform.ultralytics.com/api/trash
    ```

    ```python
    client.lifecycle.delete_trash(body={"all": True})
    ```

Restoring and deleting require Editor access or higher.

## FAQ

### Can I restore an item after 30 days?

No. After 30 days, items are permanently deleted and cannot be recovered. Make sure to restore important items before the expiration date shown in Trash.

### What happens when I delete a project with models?

Both the project and all active models inside it move to Trash together. Restoring the project restores the models that
were trashed with it. A cascaded model cannot be restored while its parent project remains in Trash.

### Do items in Trash count toward storage?

Yes, items in Trash continue to use storage quota. To free up space, permanently delete items or empty Trash.

### Can I recover a model if its project was permanently deleted?

No. If a project is permanently deleted, all models that were inside it are also permanently deleted. Always restore items before the 30-day window expires.

### How do I know when an item will be permanently deleted?

Each item in Trash shows an "Expires" column with the number of days (e.g. "30d") until automatic permanent deletion occurs.
